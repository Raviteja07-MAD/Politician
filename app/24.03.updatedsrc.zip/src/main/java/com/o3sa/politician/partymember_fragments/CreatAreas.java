package com.o3sa.politician.partymember_fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.o3sa.politician.AddressPicking.FetchCurntLocatn;
import com.o3sa.politician.R;
import com.o3sa.politician.customfonts.CustomEditText;
import com.o3sa.politician.sidemenu.SideMenu;
import com.o3sa.politician.sidemenu.SideMenu_user;
import com.o3sa.politician.storedobjects.StoredObjects;

import static com.o3sa.politician.sidemenu.SideMenu.btm_log_catch_img;
import static com.o3sa.politician.sidemenu.SideMenu.btm_log_catch_lay;
import static com.o3sa.politician.sidemenu.SideMenu.btm_log_catch_txt;

public class CreatAreas extends Fragment {

    LinearLayout pickuploc_lay;
    CustomEditText any_pickup_edtx;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater , @Nullable ViewGroup container , @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate ( R.layout.creat_area, null , false);
        StoredObjects.page_type = "cratearea";
        SideMenu.updatemenu(StoredObjects.page_type);
        try {
            SideMenu.title_txt.setText("Create Areas");
        }catch (Exception e){

        }

        init (v);
        return v;
    }

    private void init(View v) {

        pickuploc_lay = v.findViewById(R.id.pickuploc_lay);
        any_pickup_edtx = v.findViewById(R.id.any_pickup_edtx);

        any_pickup_edtx.setText(StoredObjects.pickupval);

        any_pickup_edtx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StoredObjects.tab_type ="creatadres";
                fragmentcallinglay(new FetchCurntLocatn());
            }
        });

    }

    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity ().getSupportFragmentManager ();
        fragmentManager.beginTransaction ().replace (R.id.frame_container , fragment).addToBackStack( "" ).commit ();
    }



}
