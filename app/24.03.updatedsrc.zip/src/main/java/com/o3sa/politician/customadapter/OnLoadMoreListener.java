package com.o3sa.politician.customadapter;

/**
 * Created by shrythi on 4/9/2018.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}