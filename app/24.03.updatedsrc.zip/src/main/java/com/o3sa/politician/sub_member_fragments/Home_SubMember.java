package com.o3sa.politician.sub_member_fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.o3sa.politician.R;
import com.o3sa.politician.customadapter.CustomRecyclerview;
import com.o3sa.politician.customadapter.HashMapRecycleviewadapter;
import com.o3sa.politician.partymember_fragments.Donation;
import com.o3sa.politician.partymember_fragments.Followers;
import com.o3sa.politician.partymember_fragments.Following;
import com.o3sa.politician.partymember_fragments.Members;
import com.o3sa.politician.sidemenu.SideMenu_SubMember;
import com.o3sa.politician.storedobjects.StoredObjects;

import java.util.ArrayList;
import java.util.HashMap;

import static com.o3sa.politician.sidemenu.SideMenu_SubMember.btm_log_catch_img;
import static com.o3sa.politician.sidemenu.SideMenu_SubMember.btm_log_catch_lay;
import static com.o3sa.politician.sidemenu.SideMenu_SubMember.btm_log_catch_txt;
import static com.o3sa.politician.sidemenu.SideMenu_SubMember.buttonchangemethod;
import static com.o3sa.politician.sidemenu.SideMenu_SubMember.list_slidermenu_lay;
import static com.o3sa.politician.sidemenu.SideMenu_SubMember.mDrawerLayout;


public class Home_SubMember extends Fragment {

    RecyclerView landing_recycle;
    CustomRecyclerview customRecyclerview;
    LinearLayout fishing_spots_lay,top_lay,fish_breads_lay,guide_lay,popular_lay;
    ImageView custm_menu_img,custm_search_img;
    public static int drawablecount = 0;
    public ArrayList<HashMap<String, String>> getpostlist = new ArrayList<>();
    public ArrayList<HashMap<String, String>> getpostlistall = new ArrayList<>();
    LinearLayout nodatafound_lay,followers_lay,following_lay,members_lay,donatn_lay;
    CoordinatorLayout cordinator_layout;

    SwipeRefreshLayout swipeRefreshLayout ;

    String total_results = "0",total_pages = "0",results_count = "0";
    int pageCount = 1;
    public static HashMapRecycleviewadapter adapter;
    private boolean loading = true;
    private int previousTotal = 0;
    private int visibleThreshold = 5;
    int firstVisibleItem, visibleItemCount, totalItemCount,lastVisibleItem;
    NestedScrollView mNestedScrollView;
    ProgressBar progressBar1;

    public ArrayList<HashMap<String, String>> setngs_profilelist = new ArrayList<>();
    String[] c_settingslist  = {String.valueOf(R.drawable.kcr_one_pleanary),String.valueOf(R.drawable.ktr_singapore),String.valueOf(R.drawable.harishrao),String.valueOf(R.drawable.kcr_modi_meeting),String.valueOf(R.drawable.cmrbasnthapnchmi)};
    String[] title_list  = {"KCR in Party plenary meeting ","KTR Minister Meeting With Singapore Consul General","Droughts to end in Telangana: Harish Rao","PM Modi's appreciation of TRS leaves BJP unit in Telangana.","Basantha panchami celebrations"};

    @Override
    public void onResume() {
        super.onResume();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.home_submember,null,false );
        StoredObjects.page_type="home";
        StoredObjects.back_type="home";
        SideMenu_SubMember.updatemenu(StoredObjects.page_type);

        try{
            SideMenu_SubMember.buttonchangemethod (getActivity() , btm_log_catch_lay , btm_log_catch_img , btm_log_catch_txt ,"0");
            SideMenu_SubMember.buttonchangemethod (getActivity() , SideMenu_SubMember.btm_log_catch_lay , SideMenu_SubMember.btm_log_catch_img , SideMenu_SubMember.btm_log_catch_txt ,"0");


        } catch (Exception e) {
            e.printStackTrace();
        }
        initilization(v);

        loadpostsdata(pageCount);

        return v;
    }

    public void loadpostsdata(int pageCount){

    }

    private void initilization(View v) {

        landing_recycle = (RecyclerView) v.findViewById( R.id.submember_landing_recycle );
        customRecyclerview = new CustomRecyclerview(getActivity());
        top_lay = (LinearLayout)v.findViewById( R.id.top_lay );
        nodatafound_lay = (LinearLayout) v.findViewById( R.id.nodatafound_lay );
        custm_menu_img = v.findViewById( R.id.custm_menu_img );
        // mNestedScrollView = (NestedScrollView) v.findViewById(R.id.mNestedScrollView);
        progressBar1 = v.findViewById( R.id.progressBar1 );
        following_lay = v.findViewById( R.id.following_lay );
        followers_lay = v.findViewById( R.id.followers_lay );
        members_lay = v.findViewById( R.id.members_lay );
        donatn_lay = v.findViewById( R.id.donatn_lay );

        custm_menu_img.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                drawablecount++;
                if (drawablecount == 1) {
                    mDrawerLayout.openDrawer(list_slidermenu_lay);
                } else {
                    drawablecount = 0;
                    mDrawerLayout.closeDrawer(list_slidermenu_lay);
                }
            }

        });

        members_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay(new Members());
            }
        });


        followers_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay(new Followers());
            }
        });

        following_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentcallinglay(new Following());
            }
        });


        donatn_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay(new Donation());
            }
        });

        final LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
        landing_recycle.setLayoutManager(linearLayoutManager);

        setngs_profilelist.clear();
        for (int i = 0;i<c_settingslist.length;i++){
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("images",c_settingslist[i]);
            hashMap.put("title",title_list[i]);
            setngs_profilelist.add(hashMap);
        }
        customRecyclerview.Assigndatatorecyleviewhashmap( landing_recycle, setngs_profilelist,"feedpage", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.home_submember_listitems);
    }

    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }
}
