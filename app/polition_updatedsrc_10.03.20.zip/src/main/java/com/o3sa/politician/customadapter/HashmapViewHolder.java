package com.o3sa.politician.customadapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.o3sa.politician.R;
import com.o3sa.politician.circularimageview.CircularImageView;
import com.o3sa.politician.customfonts.CustomRegularTextView;
import com.o3sa.politician.partymember_fragments.Addpost;
import com.o3sa.politician.servicesparsing.InterNetChecker;
import com.o3sa.politician.storedobjects.StoredObjects;
import com.o3sa.politician.storedobjects.StoredUrls;
import com.o3sa.politician.user_fragments.Feed_innerpage_user;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by VINI on 20-03-2019.
 */

public class HashmapViewHolder extends RecyclerView.ViewHolder {

   private Activity activity;


    // feedpage
    ImageView post_img,landing_dots_image;
    CustomRegularTextView dscrption_txt;

    // notifications
    CustomRegularTextView ntfc_profile_name_txt,ntfc_txt;
    CircularImageView landing_circular_img;

    // profile_followers
    CircularImageView following_circular_img;
    CustomRegularTextView profile_name_txt;


    public HashmapViewHolder(View convertView, String type, final Activity activity) {

       super(convertView);
        this.activity = activity;
       // database = new Database(activity);




        if (type.equalsIgnoreCase("feedpage")) {

            post_img = convertView.findViewById(R.id.post_img);
            landing_dots_image = convertView.findViewById(R.id.landing_dots_image);
            dscrption_txt = convertView.findViewById(R.id.dscrption_txt);

        }

        if (type.equalsIgnoreCase("notifications")) {

            ntfc_profile_name_txt = convertView.findViewById(R.id.ntfc_profile_name_txt);
            ntfc_txt = convertView.findViewById(R.id.ntfc_txt);
            landing_circular_img = convertView.findViewById(R.id.landing_circular_img);

        }

        if (type.equalsIgnoreCase("profile_followers")) {

            profile_name_txt = convertView.findViewById(R.id.profile_name_txt);
            following_circular_img = convertView.findViewById(R.id.following_circular_img);

        }

        if (type.equalsIgnoreCase("Followers")) {

            profile_name_txt = convertView.findViewById(R.id.profile_name_txt);
            following_circular_img = convertView.findViewById(R.id.following_circular_img);

        }

        if (type.equalsIgnoreCase("following")) {

            profile_name_txt = convertView.findViewById(R.id.profile_name_txt);
            following_circular_img = convertView.findViewById(R.id.following_circular_img);

        }


    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)

    public void assign_data(final ArrayList<HashMap<String, String>> datalist, final int position, final String formtype) {


        if (formtype.equalsIgnoreCase("feedpage")) {

            dscrption_txt.setText(datalist.get(position).get("title"));
            post_img.setImageResource(Integer.parseInt(datalist.get(position).get("images")));

            post_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    fragmentcalling_comments(new Feed_innerpage_user(),datalist,position);
                }
            });

            landing_dots_image.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    EditDeleteConfirmation( activity, datalist, position ,"");

                }
            } );


        }

        if (formtype.equalsIgnoreCase("notifications")) {

            ntfc_profile_name_txt.setText(datalist.get(position).get("title"));
            ntfc_txt.setText(datalist.get(position).get("notifictitle"));
            landing_circular_img.setImageResource(Integer.parseInt(datalist.get(position).get("images")));

        }

        if (formtype.equalsIgnoreCase("profile_followers")) {

            profile_name_txt.setText(datalist.get(position).get("title"));
            following_circular_img.setImageResource(Integer.parseInt(datalist.get(position).get("images")));

        }

        if (formtype.equalsIgnoreCase("Followers")) {

            profile_name_txt.setText(datalist.get(position).get("title"));
            following_circular_img.setImageResource(Integer.parseInt(datalist.get(position).get("images")));

        }

        if (formtype.equalsIgnoreCase("following")) {

            profile_name_txt.setText(datalist.get(position).get("title"));
            following_circular_img.setImageResource(Integer.parseInt(datalist.get(position).get("images")));

        }

    }

    public void fragmentcalling_comments(Fragment fragment, ArrayList<HashMap<String, String>> list, int position) {
        FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
        Bundle bundle = new Bundle();
        bundle.putSerializable("YourHashMap", list);
        bundle.putInt("position", position);
        fragment.setArguments(bundle);
        fragmentManager.beginTransaction()/*.setCustomAnimations(R.anim.falldown, R.anim.falldown)*/.replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }


    private void EditDeleteConfirmation(final Activity activity, final ArrayList<HashMap<String, String>> list, final int position,String posttype) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.editdelete_confirmation );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            dialog.getWindow().setElevation(20);
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout cancel_lay = (LinearLayout)dialog.findViewById(R.id.cancel_lay);

        LinearLayout edit_layout = (LinearLayout)dialog.findViewById(R.id.edit_layout);
        LinearLayout delet_layout = (LinearLayout)dialog.findViewById(R.id.delet_layout);
        LinearLayout blockuser_layout = (LinearLayout)dialog.findViewById(R.id.blockuser_layout);
        LinearLayout hidepost_layout = (LinearLayout)dialog.findViewById(R.id.hidepost_layout);


        /*if (posttype.equalsIgnoreCase( "sharedpost" )) {
            if (list.get( position ).get( "shared_by_customer_id" ).equalsIgnoreCase( StoredObjects.UserId )) {
                edit_layout.setVisibility( View.VISIBLE );
                delet_layout.setVisibility( View.VISIBLE );
                blockuser_layout.setVisibility( View.GONE );
                hidepost_layout.setVisibility( View.GONE );

            } else {
                edit_layout.setVisibility( View.GONE );
                delet_layout.setVisibility( View.GONE );
                blockuser_layout.setVisibility( View.VISIBLE );
                hidepost_layout.setVisibility( View.VISIBLE );
            }
        }
        if (posttype.equalsIgnoreCase( "sharedpost_own" )) {
            if(list.get( position ).get( "shared_by_customer_id" ).equalsIgnoreCase(StoredObjects.UserId)){
                edit_layout.setVisibility(View.VISIBLE);
                delet_layout.setVisibility(View.VISIBLE);
                blockuser_layout.setVisibility(View.GONE);
                hidepost_layout.setVisibility(View.GONE);

            }else{
                edit_layout.setVisibility(View.GONE);
                delet_layout.setVisibility(View.GONE);
                blockuser_layout.setVisibility(View.VISIBLE);
                hidepost_layout.setVisibility(View.VISIBLE);
            }
        }else {
            if(list.get( position ).get( "customer_id" ).equalsIgnoreCase(StoredObjects.UserId)){
                edit_layout.setVisibility(View.VISIBLE);
                delet_layout.setVisibility(View.VISIBLE);
                blockuser_layout.setVisibility(View.GONE);
                hidepost_layout.setVisibility(View.GONE);
            }else{
                edit_layout.setVisibility(View.GONE);
                delet_layout.setVisibility(View.GONE);
                blockuser_layout.setVisibility(View.VISIBLE);
                hidepost_layout.setVisibility(View.VISIBLE);
            }

        }*/

        hidepost_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

                if (InterNetChecker.isNetworkAvailable(activity)) {
                 //   new HidepostTask().execute(StoredObjects.UserId,list.get( position ).get("post_id"));
                   // updateqtydata(list,list.get( position ),position,"No","landingpage_hidepost");

                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }
            }
        });


        blockuser_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

                if (InterNetChecker.isNetworkAvailable(activity)) {
                  //  new BlockUserTask().execute(list.get( position ).get( "customer_id" ));
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }
            }
        });

        if (posttype.equalsIgnoreCase( "sharedpost_own" )){
            edit_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    /*fragmentcalling1(new Addpost(),list,position);*/
                   // Sharepostpopup( activity,list,position,list.get( position ).get( "original_post_id" ),"sharedpost");
                    dialog.dismiss();
                }
            });
        }else{
            edit_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   // fragmentcalling1(new Addpost(),list,position);
                    dialog.dismiss();
                }
            });
        }



        delet_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
                if (InterNetChecker.isNetworkAvailable(activity)) {
                   // new DeletePostTask().execute(list.get( position ).get( "post_id" ));
                   // updateqtydata(list,list.get( position ),position,"No","landingpage_delete");
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }

            }
        });



        cancel_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });



        dialog.show();
    }


}

