package com.o3sa.politician.partymember_fragments;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.o3sa.politician.R;
import com.o3sa.politician.customadapter.CustomRecyclerview;
import com.o3sa.politician.customfonts.CustomEditText;
import com.o3sa.politician.servicesparsing.InterNetChecker;
import com.o3sa.politician.sidemenu.SideMenu;
import com.o3sa.politician.sidemenu.SideMenu_user;
import com.o3sa.politician.storedobjects.StoredObjects;

import java.util.ArrayList;
import java.util.HashMap;

import static com.o3sa.politician.sidemenu.SideMenu.btm_addpost_txt;
import static com.o3sa.politician.sidemenu.SideMenu.btm_log_catch_img;
import static com.o3sa.politician.sidemenu.SideMenu.btm_log_catch_lay;
import static com.o3sa.politician.sidemenu.SideMenu.btm_log_catch_txt;
import static com.o3sa.politician.sidemenu.SideMenu.btm_map_img;
import static com.o3sa.politician.sidemenu.SideMenu.btm_map_lay;
import static com.o3sa.politician.sidemenu.SideMenu.btm_map_txt;
import static com.o3sa.politician.sidemenu.SideMenu.buttonchangemethod;
import static com.o3sa.politician.sidemenu.SideMenu.custm_menu_img;

public class Donation extends Fragment {

    CustomRecyclerview customRecyclerview;
    public static ArrayList<HashMap<String,String>> relationlist=new ArrayList<>();
    //capture camera
    // Activity request codes
    private static final int CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
    // key to store image path in savedInstance state
    public static final String KEY_IMAGE_STORAGE_PATH = "image_path";
    public static final int MEDIA_TYPE_IMAGE = 1;
    // Bitmap sampling size
    public static final int BITMAP_SAMPLE_SIZE = 8;
    // Gallery directory name to store the images or videos
    public static final String GALLERY_DIRECTORY_NAME = "ProfileImages";
    // Image and Video file extensions
    public static final String IMAGE_EXTENSION = "jpg";
    private static String imageStoragePath;

    protected static final int SELECT_FILE = 1;
    private static final int PIC_CROP = 3;
    String image_str="";
    private Bitmap myImg;
    private String fileName;
    String file_name;
    public static RecyclerView kidpick_recycle;
    public static LinearLayout nodata_found_txt;
    CustomEditText parent_photo_edtxt;
    LinearLayout addevent_btn;
    TextView title_txt;
    ImageView backbtn_img;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate ( R.layout.donation, null , false);
        StoredObjects.page_type="Events";
        StoredObjects.back_type="Events";
        SideMenu.updatemenu(StoredObjects.page_type);

        try{
            SideMenu.buttonchangemethod (getActivity() , btm_log_catch_lay , btm_log_catch_img , btm_log_catch_txt ,"0");
            SideMenu_user.buttonchangemethod (getActivity() , SideMenu_user.btm_log_catch_lay , SideMenu_user.btm_log_catch_img , SideMenu_user.btm_log_catch_txt ,"0");

        } catch (Exception e) {
            e.printStackTrace();
        }



        init (v);
        if (InterNetChecker.isNetworkAvailable(getActivity())) {
           // new GetRealtionTask().execute(StoredObjects.UserId);
        }else{
            StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet),getActivity());
        }

        return v;
    }

    private void init(View v) {

        title_txt = (TextView)v.findViewById( R.id. title_txt);
        backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );


        kidpick_recycle= v.findViewById(R.id.kidpick_recycle);
        addevent_btn = v.findViewById( R.id.addevent_btn );
        customRecyclerview = new CustomRecyclerview(getActivity());
        nodata_found_txt = (LinearLayout) v.findViewById(R.id.nodata_found_txt);

        title_txt.setText( R.string.donations );

        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new Home() );
            }
        } );

        try{
            //   UserSidemenu.cstm_srch_img.setVisibility(View.VISIBLE);
        }catch (Exception e){

        }

        StoredObjects.hashmaplist(4);
        customRecyclerview.Assigndatatorecyleviewhashmap(kidpick_recycle, StoredObjects.dummy_list,"kidpick", StoredObjects.Listview,0, StoredObjects.ver_orientation, R.layout.donationlisitem);


        addevent_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new Add_donation() );

               /* if (relationlist.size()>=4){
                    StoredObjects.Logoutpopup( getActivity(),"Maximum limit is exceeded" );
                }
                else {*/
                //fragmentcallinglay( new Add_event() );
                //}


                //addparentpopup(getActivity());

            }
        } );

    }


    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity ().getSupportFragmentManager ();
        fragmentManager.beginTransaction ().replace (R.id.frame_container , fragment).addToBackStack( "" ).commit ();
    }


/*
    public class GetRealtionTask extends AsyncTask<String, String, String> {
        String strResult = "";
        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(getActivity());
        }
        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token",StoredUrls.token));
                nameValuePairs.add(new BasicNameValuePair("type",StoredUrls.get_relation));
                nameValuePairs.add(new BasicNameValuePair("user_id",params[0]));
                strResult = HttpPostClass.PostMethod(StoredUrls.ParentBaseUrl,nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject = new JSONObject( result );
                String status = jsonObject.getString( "status" );
                if (status.equalsIgnoreCase( "200" )) {
                    String results = jsonObject.getString( "results" );
                    relationlist = JsonParsing.GetJsonData( results );

                    if (relationlist.size() == 0) {
                        nodata_found_txt.setVisibility( View.VISIBLE );
                        kidpick_recycle.setVisibility( View.GONE );
                    } else {
                        nodata_found_txt.setVisibility( View.GONE );
                        kidpick_recycle.setVisibility( View.VISIBLE );
                        customRecyclerview.Assigndatatorecyleviewhashmap( kidpick_recycle, relationlist, "Relation_parent", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.pickkidlisitem );


                    }
                }else{
                    nodata_found_txt.setVisibility(View.VISIBLE);
                    kidpick_recycle.setVisibility(View.GONE);
                   // String error= jsonObject.getString("error");
                    //StoredObjects.ToastMethod(error,getActivity());
                }
            }catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }
*/

}
