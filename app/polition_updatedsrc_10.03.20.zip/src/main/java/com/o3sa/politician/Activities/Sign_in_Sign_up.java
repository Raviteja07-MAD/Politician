package com.o3sa.politician.Activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.o3sa.politician.R;
import com.o3sa.politician.customfonts.CustomButton;
import com.o3sa.politician.customfonts.CustomEditText;
import com.o3sa.politician.customfonts.CustomRegularTextView;
import com.o3sa.politician.sidemenu.SideMenu;
import com.o3sa.politician.sidemenu.SideMenu_user;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


public class Sign_in_Sign_up extends AppCompatActivity {

    CustomRegularTextView sign_in_text,sign_up_text,frgt_password_text;
    LinearLayout sign_in_layout,signup_layout,google_signin_btn,login_fbbtn,fb_signin_btn;
    CustomButton sign_in_btn,sign_up_btn;
    String name="",phone_number="",email_id="",password="",confrm_password="",signin_email_id="",signin_password="";
    TextInputEditText sign_up_phone_edtxt,sign_up_email_edtxt,sign_up_password_edtxt,sign_up_cnfrmpsswrd_edtxt;
    CustomRegularTextView terms_conditions_text;
    TextInputEditText sign_in_email_edtxt,sign_in_passwrd_edtxt,sign_up_name_edtxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.sign_in );

        initialization();
    }

    private void initialization() {

        signup_layout = (LinearLayout)findViewById( R.id.signup_layout );
        sign_up_btn = (CustomButton)findViewById( R.id.sign_up_btn );
        sign_up_name_edtxt =(TextInputEditText)findViewById( R.id.sign_up_name_edtxt);
        sign_up_phone_edtxt =(TextInputEditText)findViewById( R.id.sign_up_phone_edtxt);
        sign_up_email_edtxt =(TextInputEditText)findViewById( R.id.sign_up_email_edtxt);
        sign_up_password_edtxt =(TextInputEditText)findViewById( R.id.sign_up_password_edtxt);
        sign_up_cnfrmpsswrd_edtxt =(TextInputEditText)findViewById( R.id.sign_up_cnfrmpsswrd_edtxt);
        sign_in_text = (CustomRegularTextView)findViewById( R.id.sign_in_text );
        sign_up_text = (CustomRegularTextView)findViewById( R.id.sign_up_text );
        frgt_password_text = (CustomRegularTextView)findViewById( R.id.frgt_password_text );
        sign_in_layout = (LinearLayout)findViewById( R.id.sign_in_layout );
        signup_layout = (LinearLayout)findViewById( R.id.signup_layout );
        terms_conditions_text = findViewById (R.id.terms_conditions_text);
        sign_in_btn = (CustomButton)findViewById( R.id.sign_in_btn );
        sign_in_email_edtxt =(TextInputEditText)findViewById( R.id.sign_in_email_edtxt);

        terms_conditions_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Sign_in_Sign_up.this, TermsAndConditions.class);
                startActivity(intent);
            }
        });

        //sign_in_email_edtxt.setText("android@gmail.com");
        //sign_in_passwrd_edtxt.setText("0000");



        sign_in_text.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonchangemethod (Sign_in_Sign_up.this ,sign_in_layout, sign_in_text  ,"0");
            }
        } );

        sign_up_text.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonchangemethod (Sign_in_Sign_up.this ,signup_layout, sign_up_text  ,"1");
            }
        } );

        frgt_password_text.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(Sign_in_Sign_up.this, Forgot_password.class));
            }
        } );

        sign_in_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (sign_in_email_edtxt.getText().toString().equalsIgnoreCase("1111")){
                    Intent intent = new Intent( Sign_in_Sign_up.this, SideMenu_user.class );
                    intent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
                    startActivity(intent);
                    Sign_in_Sign_up.this.finish();

                }else if(sign_in_email_edtxt.getText().toString().equalsIgnoreCase("0000")){

                    Intent intent = new Intent( Sign_in_Sign_up.this, SideMenu.class );
                    intent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
                    startActivity(intent);
                    Sign_in_Sign_up.this.finish();
                }



            }
        });
/*
        sign_in_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                signin_email_id = sign_in_email_edtxt.getText().toString();
                signin_password = sign_in_passwrd_edtxt.getText().toString();

                if (StoredObjects.inputValidation( sign_in_email_edtxt, getApplicationContext().getResources().getString( R.string.enteremail ), Sign_in_Sign_up.this )) {
                    if (StoredObjects.inputValidation( sign_in_passwrd_edtxt, getApplicationContext().getResources().getString( R.string.enterpassword ), Sign_in_Sign_up.this )) {

                        StoredObjects.hide_keyboard( Sign_in_Sign_up.this );
                        if (InterNetChecker.isNetworkAvailable( Sign_in_Sign_up.this )) {
                            new Signin_Task().execute( signin_email_id, signin_password,StoredObjects.gcm_regid );

                        } else {
                            StoredObjects.ToastMethod( getApplicationContext().getResources().getString( R.string.checkinternet ), Sign_in_Sign_up.this );
                        }
                    }
                }
            }
        } );
*/


        sign_up_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 startActivity(new Intent(Sign_in_Sign_up.this, OtpVerification.class));


            }
        });


/*
        sign_up_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                name = sign_up_name_edtxt.getText().toString();
                phone_number = sign_up_phone_edtxt.getText().toString();
                email_id = sign_up_email_edtxt.getText().toString();
                password = sign_up_password_edtxt.getText().toString();
                confrm_password = sign_up_cnfrmpsswrd_edtxt.getText().toString();

                if (StoredObjects.inputValidation( sign_up_name_edtxt, getApplicationContext().getResources().getString( R.string.entername ), Sign_in_Sign_up.this )) {
                    if (StoredObjects.inputValidation( sign_up_phone_edtxt, getApplicationContext().getResources().getString( R.string.entermobile ), Sign_in_Sign_up.this )) {
                        if (StoredObjects.inputValidation( sign_up_email_edtxt, getApplicationContext().getResources().getString( R.string.enteremail ), Sign_in_Sign_up.this )) {
                            if (StoredObjects.inputValidation( sign_up_password_edtxt, getApplicationContext().getResources().getString( R.string.enterpassword ), Sign_in_Sign_up.this )) {
                                if (StoredObjects.inputValidation( sign_up_cnfrmpsswrd_edtxt, getApplicationContext().getResources().getString( R.string.cnfrmpassword ), Sign_in_Sign_up.this )) {
                                    if (confrm_password.equals( password ) ) {
                                        StoredObjects.hide_keyboard( Sign_in_Sign_up.this );
                                        if (InterNetChecker.isNetworkAvailable( Sign_in_Sign_up.this )) {
                                            if(StoredObjects.isValidEmail(email_id)){

                                                new Signup_Task().execute( name, phone_number, email_id, password ,confrm_password );

                                            }else{
                                                StoredObjects.ToastMethod( getApplicationContext().getResources().getString( R.string.please_entervalidemail), Sign_in_Sign_up.this );
                                            }
                                        } else {
                                            StoredObjects.ToastMethod( getApplicationContext().getResources().getString( R.string.checkinternet ), Sign_in_Sign_up.this );
                                        }
                                    } else {
                                        StoredObjects.ToastMethod( "passwords not matched", Sign_in_Sign_up.this );
                                    }

                                }
                            }
                        }
                    }
                }
            }
        } );
*/

    }

    public void buttonchangemethod(Activity activity , LinearLayout layout1, TextView text1 , String type) {

        signup_layout.setVisibility( View.GONE );
        sign_in_layout.setVisibility( View.GONE );

        sign_in_text.setBackgroundResource( R.drawable.signin_white_btn_bg );
        sign_up_text.setBackgroundResource( R.drawable.signin_white_btn_bg );

        sign_up_text.setTextColor( getResources().getColor(R.color.form_text_color));
        sign_in_text.setTextColor( getResources().getColor(R.color.form_text_color));


        layout1.setVisibility( View.VISIBLE );
        text1.setTextColor (activity.getResources ().getColor (R.color.white));
        text1.setBackgroundResource( R.drawable.signin_btn_bg );
    }

/*
    public class Signup_Task extends AsyncTask<String, String, String> {
        String strResult = "";
        String enter_email = "";
        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(Sign_in_Sign_up.this);        }
        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("method","register"));
                nameValuePairs.add(new BasicNameValuePair("name",params[0]));
                nameValuePairs.add(new BasicNameValuePair("mobile_type","Android"));
                nameValuePairs.add(new BasicNameValuePair("phone",params[1]));
                nameValuePairs.add(new BasicNameValuePair("email",params[2]));
                nameValuePairs.add(new BasicNameValuePair("password",params[3]));

                enter_email = params[2];
                strResult = HttpPostClass.PostMethod( StoredUrls.BaseUrl,nameValuePairs);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(Sign_in_Sign_up.this);            }
            try {

                JSONObject jsonObject =  new JSONObject(result);
                String status = jsonObject.getString("status");
                if(status.equalsIgnoreCase("200")){
                    enter_email = "";
                    buttonchangemethod (Sign_in_Sign_up.this ,sign_in_layout, sign_in_text  ,"0");

                    sign_up_name_edtxt.setText("");
                    sign_up_phone_edtxt.setText("");
                    sign_up_email_edtxt.setText("");
                    sign_up_password_edtxt.setText("");
                    sign_up_cnfrmpsswrd_edtxt.setText("");

                    StoredObjects.ToastMethod("Successfully Registered.",Sign_in_Sign_up.this);


                    String customer_id = jsonObject.getString("customer_id");
                }else{
                    String error= jsonObject.getString("error");
                   // StoredObjects.ToastMethod("Sign Up failed..",Sign_in_Sign_up.this);
                    StoredObjects.ToastMethod(error,Sign_in_Sign_up.this);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }
*/

/*
    public class Signin_Task extends AsyncTask<String, String, String> {
        String strResult = "";
        String enterd_email = "";
        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(Sign_in_Sign_up.this);
        }
        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("method","login"));
                nameValuePairs.add(new BasicNameValuePair("email",params[0]));
                nameValuePairs.add(new BasicNameValuePair("password",params[1]));
                nameValuePairs.add(new BasicNameValuePair("gcm_regid",params[2]));
                nameValuePairs.add(new BasicNameValuePair("phone_type","Android"));

                enterd_email = params[0];
                strResult = HttpPostClass.PostMethod( StoredUrls.BaseUrl,nameValuePairs);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                 CustomProgressbar.Progressbarcancel(Sign_in_Sign_up.this);
            }
            try {

                JSONObject jsonObject =  new JSONObject(result);
                String status = jsonObject.getString("status");
                if(status.equalsIgnoreCase("200")){
                    StoredObjects.UserId = jsonObject.getString("customer_id");
                    database.UpdateUserId(StoredObjects.UserId);
                    logUser(email_id,StoredObjects.UserId);
                    Intent intent = new Intent( Sign_in_Sign_up.this, SideMenu.class );
                    intent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
                    startActivity(intent);
                    Sign_in_Sign_up.this.finish();
                }else{
                    String error= jsonObject.getString("error");
                    StoredObjects.ToastMethod(error,Sign_in_Sign_up.this);
                    //StoredObjects.ToastMethod("Invalid Email/Password",Sign_in_Sign_up.this);
                }



            } catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }
*/


/*
    private void logUser(String email, String id) {
        // TODO: Use the current user's information
        // You can call any combination of these three methods
        Crashlytics.setUserIdentifier(id);
        Crashlytics.setUserEmail(email);
        Crashlytics.setUserName("Test User");
    }
*/
}
