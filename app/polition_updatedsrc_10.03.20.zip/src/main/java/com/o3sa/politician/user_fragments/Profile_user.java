package com.o3sa.politician.user_fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.NetworkOnMainThreadException;
import android.os.StrictMode;
import android.provider.MediaStore;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.o3sa.politician.R;
import com.o3sa.politician.circularimageview.CircularImageView;
import com.o3sa.politician.customfonts.CustomButton;
import com.o3sa.politician.customfonts.CustomEditText;
import com.o3sa.politician.partymember_fragments.Home;
import com.o3sa.politician.servicesparsing.InterNetChecker;
import com.o3sa.politician.sidemenu.SideMenu_user;
import com.o3sa.politician.storedobjects.CameraUtils;
import com.o3sa.politician.storedobjects.StoredObjects;
import com.o3sa.politician.storedobjects.StoredUrls;

import org.apache.http.NameValuePair;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;


import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static com.o3sa.politician.sidemenu.SideMenu_user.btm_profile_img;
import static com.o3sa.politician.sidemenu.SideMenu_user.btm_profile_lay;
import static com.o3sa.politician.sidemenu.SideMenu_user.btm_profile_txt;

public class Profile_user extends Fragment {

    CircularImageView prf_prfle_img;
    ImageView prf_edtcam_img;
    LinearLayout prf_edtcam_lay,prf_name_lay,prf_age_lay,prf_email_lay,prf_city_lay,prf_phne_lay,prf_adres_lay;
    static CustomEditText prf_name_edtx,prf_gendr_edtx,prf_age_edtx,prf_email_edtx,prf_city_edtx,prf_phone_edtx,prf_adres_edtx;
    CustomButton prf_sbmt_btn;

    //image upload
    public static String fileName = "";
    String filename ="";

    //image upload
    public static final int MY_PERMISSIONS_REQUEST_WRITE_CALENDAR = 123;
    protected static final int SELECT_FILE = 1;
    private static final int CAPTURE_CAMERA = 2;
    private static final int PIC_CROP = 3;
    private Bitmap myImg;
    private File compressedImage;

    //capture camera
    // Activity request codes
    private static final int CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
    public static final int MEDIA_TYPE_IMAGE = 1;
    private static String imageStoragePath;

    public static ArrayList<HashMap<String, String>> getprofilelist = new ArrayList<>();

    private ListPopupWindow listPopupWindow;
    String[] gnderlst = {"MALE","FEMALE"};
    String[] citylist = {"Hyderabad","Chennai","Mumbai","Bengaluru","Kochi","Pune"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.profile_user,container,false);
        listPopupWindow = new ListPopupWindow(getActivity());
        StoredObjects.page_type="profile";
        StoredObjects.back_type="profile";

        try
        {
            SideMenu_user.buttonchangemethod (getActivity() , btm_profile_lay , btm_profile_img , btm_profile_txt , "4");

        } catch (Exception e) {
            e.printStackTrace();
        }
        SideMenu_user.updatemenu(StoredObjects.page_type);
        intialization(v);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        // Checking availability of the camera
        if (!CameraUtils.isDeviceSupportCamera(getActivity())) {
            Toast.makeText(getActivity(),
                    "Sorry! Your device doesn't support camera",
                    Toast.LENGTH_LONG).show();
            // will close the app if the device doesn't have camera
        }

        if (InterNetChecker.isNetworkAvailable(getActivity())) {
         //   new GetProfileTask().execute(StoredObjects.token, StoredUrls.getprofile,StoredObjects.UserId);
        }else{
            StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet),getActivity());
        }

        return v;
    }

    public void intialization(View v) {

        try {
           // Sidemenu.custm_title_txt.setText("Profile");
        }catch (Exception e){
        }

        prf_edtcam_lay = (LinearLayout) v.findViewById(R.id.prf_edtcam_lay);
        prf_prfle_img = (CircularImageView) v.findViewById(R.id.prf_prfle_img);
        prf_edtcam_img = (ImageView) v.findViewById(R.id.prf_edtcam_img);

        prf_name_lay = (LinearLayout) v.findViewById(R.id.prf_name_lay);
        prf_age_lay = (LinearLayout) v.findViewById(R.id.prf_age_lay);
        prf_email_lay = (LinearLayout) v.findViewById(R.id.prf_email_lay);
        prf_city_lay = (LinearLayout) v.findViewById(R.id.prf_city_lay);
        prf_phne_lay = (LinearLayout) v.findViewById(R.id.prf_phne_lay);
        prf_adres_lay = (LinearLayout) v.findViewById(R.id.prf_adres_lay);

        prf_name_edtx = (CustomEditText) v.findViewById(R.id.prf_name_edtx);
        prf_gendr_edtx = (CustomEditText) v.findViewById(R.id.prf_gendr_edtx);
        prf_age_edtx = (CustomEditText) v.findViewById(R.id.prf_age_edtx);
        prf_email_edtx = (CustomEditText) v.findViewById(R.id.prf_email_edtx);
        prf_city_edtx = (CustomEditText) v.findViewById(R.id.prf_city_edtx);
        prf_phone_edtx = (CustomEditText) v.findViewById(R.id.prf_phone_edtx);
        prf_adres_edtx = (CustomEditText) v.findViewById(R.id.prf_adres_edtx);

        prf_sbmt_btn = (CustomButton) v.findViewById(R.id.prf_sbmt_btn);


        TextView title_txt = (TextView) v.findViewById(R.id.title_txt);
        title_txt.setText(R.string.profile);

        ImageView backbtn_img = (ImageView) v.findViewById(R.id.backbtn_img);
        backbtn_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcalling(new Home());

            }
        });
        prf_edtcam_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uploadimage();
            }
        });

        prf_city_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StoredObjects.hide_keyboard(getActivity());
                SelectCityPopup(prf_city_edtx);
            }
        });

        prf_city_edtx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StoredObjects.hide_keyboard(getActivity());
                SelectCityPopup(prf_city_edtx);
            }
        });

        prf_gendr_edtx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SelectGenderPopup(prf_gendr_edtx);
            }
        });

/*
        prf_sbmt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = prf_name_edtx.getText().toString().trim();
                String gender = prf_gendr_edtx.getText().toString().trim();
                String age = prf_age_edtx.getText().toString().trim();
                String email = prf_email_edtx.getText().toString().trim();
                String adres = prf_adres_edtx.getText().toString().trim();
                String city = prf_city_edtx.getText().toString().trim();
                String phonenum = prf_phone_edtx.getText().toString().trim();


                if(StoredObjects.inputValidation(prf_name_edtx,getActivity().getResources().getString(R.string.entername),getActivity())==true)
                {
                    if (StoredObjects.inputValidation(prf_gendr_edtx, getActivity().getResources().getString(R.string.selctgender), getActivity()) == true)
                    {
                        if (StoredObjects.inputValidation(prf_age_edtx, getActivity().getResources().getString(R.string.enterage), getActivity()) == true)
                        {
                            if (StoredObjects.inputValidation(prf_email_edtx, getActivity().getResources().getString(R.string.enteremail), getActivity()) == true) {

                                // if(StoredObjects.isValidEmail(email)){

                                if (StoredObjects.inputValidation(prf_adres_edtx, getActivity().getResources().getString(R.string.enteradress), getActivity()) == true) {

                                    if (StoredObjects.inputValidation(prf_city_edtx, getActivity().getResources().getString(R.string.selctcity), getActivity()) == true) {

                                    if (StoredObjects.inputValidation(prf_phone_edtx, getActivity().getResources().getString(R.string.enterphone), getActivity()) == true) {

                                        if (!filename.equalsIgnoreCase("")) {
                                            StoredObjects.hide_keyboard(getActivity());
                                            if (InterNetChecker.isNetworkAvailable(getActivity())) {
                                                new EditPrfileTask().execute(StoredObjects.token, StoredUrls.editprofile, adres, city, gender, phonenum, filename, "image_upload", StoredObjects.UserId,name);
                                            } else {
                                                StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet), getActivity());
                                            }

                                        } else {
                                            StoredObjects.hide_keyboard(getActivity());
                                            if (InterNetChecker.isNetworkAvailable(getActivity())) {
                                                new EditPrfileTask().execute(StoredObjects.token, StoredUrls.editprofile, adres, city, gender, phonenum, filename, "no_image", StoredObjects.UserId,name);
                                            } else {
                                                StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet), getActivity());
                                            }
                                        }
                                    }
                                }

                            }
                              */
/*  }
                                else{
                                    StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.invalidemail),getActivity());

                                }*//*

                            }
                        }
                    }
                }
            }
        });
*/
    }

    private void SelectGenderPopup(final CustomEditText prfilenme){

        listPopupWindow.setAdapter(new ArrayAdapter<>(getActivity(),R.layout.drpdwn_lay,gnderlst));
        listPopupWindow.setAnchorView(prfilenme);
        listPopupWindow.setHeight(LinearLayout.MarginLayoutParams.WRAP_CONTENT);

        listPopupWindow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                prfilenme.setText(gnderlst[position]);
                listPopupWindow.dismiss();

            }
        });

        listPopupWindow.show();
    }

    private void SelectCityPopup(final CustomEditText prfilenme){

        listPopupWindow.setAdapter(new ArrayAdapter<>(getActivity(),R.layout.drpdwn_lay,citylist));
        listPopupWindow.setAnchorView(prfilenme);
        listPopupWindow.setHeight(LinearLayout.MarginLayoutParams.WRAP_CONTENT);

        listPopupWindow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                prfilenme.setText(citylist[position]);
                listPopupWindow.dismiss();

            }
        });

        listPopupWindow.show();
    }

    //imageupload
    private void uploadimage(){

        try {
            if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 1);

            } else {

                //Photo_SHowDialog(getActivity(),f_new,tempPath,pictureBitmap);
            }
        } catch (Exception e) {
        }

    }
    Dialog dialog_show;
    public void Photo_SHowDialog(final Context context, final File captured_file, final String path, final Bitmap bitmap){
        dialog_show = new Dialog(context);
        dialog_show.getWindow();

        dialog_show.requestWindowFeature( Window.FEATURE_NO_TITLE);
        dialog_show.setContentView(R.layout.photoshow_popup );
        dialog_show.getWindow().setLayout( WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog_show.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        ImageView captured_image = (ImageView) dialog_show.findViewById(R.id.captured_image);
        Button cancel_btn = (Button) dialog_show.findViewById(R.id.cancel_btn);
        Button saveandcontinue__btn = (Button) dialog_show.findViewById(R.id.saveandcontinue__btn);

        String fileNameSegments[] = path.split("/");
        fileName = fileNameSegments[fileNameSegments.length - 1];

        myImg = Bitmap.createBitmap(getResizedBitmap(getUnRotatedImage(path, BitmapFactory.decodeFile(path)), 300));
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        myImg.compress(Bitmap.CompressFormat.JPEG, 80, stream);

        captured_image.setImageBitmap(myImg);


        saveandcontinue__btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (InterNetChecker.isNetworkAvailable(getActivity())) {

                    StoredObjects.LogMethod("", "pictureFile_uploading:--"+"::path::"+path);

                    // new ImageUploadTaskNew().execute(path);


                   /* capturd_image.setImageBitmap(myImg);

                    //uploadImage();
                    bitmapToUriConverter(myImg);*/

                    dialog_show.dismiss();
                }else{
                    Toast toast = Toast.makeText(context, "Please Check Internet Connection.", Toast.LENGTH_LONG);
                    toast.show();
                }

                bitmapToUriConverter(myImg);

            }
        });

        cancel_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog_show.dismiss();

            }
        });


        dialog_show.show();

    }

    private Uri picUri;
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //user is returning from capturing an image using the camera
        if (requestCode == CAMERA_CAPTURE_IMAGE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // Refreshing the gallery
                CameraUtils.refreshGallery(getActivity(), imageStoragePath);

                try {
                    f_new = createNewFile("CROP_");
                    try {
                        f_new.createNewFile();
                    } catch (IOException ex) {
                        Log.e("io", ex.getMessage());
                    }
                    //Photo_SHowDialog(getActivity(),f_new,imageStoragePath,myBitmap);
                    imageupload(getActivity(),imageStoragePath);
                } catch (Exception e) {
                    e.printStackTrace();
                    StoredObjects.LogMethod("", "imagepathexpection:--" + e);

                }
                // successfully captured the image
                // display it in image view
                // Bitmap bitmap = CameraUtils.optimizeBitmap(BITMAP_SAMPLE_SIZE, imageStoragePath);

            } else if (resultCode == RESULT_CANCELED) {
                // user cancelled Image capture
                Toast.makeText(getActivity(),
                        "User cancelled image capture", Toast.LENGTH_SHORT)
                        .show();
            } else {
                // failed to capture image
                Toast.makeText(getActivity(),
                        "Sorry! Failed to capture image", Toast.LENGTH_SHORT)
                        .show();
            }
        }

        else if (requestCode == 2) {

            StoredObjects.LogMethod("resultcode","result code"+resultCode);
            if (resultCode == RESULT_OK) {
                Uri selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getActivity().getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();


                try {
                    Bitmap myBitmap=null;
                    picUri = data.getData();

                    myBitmap = (BitmapFactory.decodeFile(picturePath));

                    try {

                        f_new = createNewFile("CROP_");

                        try {
                            f_new.createNewFile();
                        } catch (IOException ex) {
                            Log.e("io", ex.getMessage());
                        }
                        StoredObjects.LogMethod("path", "path:::"+picturePath+"--"+myBitmap);
                        //Photo_SHowDialog(getActivity(),f_new,picturePath,myBitmap);
                        imageupload(getActivity(),picturePath);
                        //new ImageUploadTaskNew().execute(docFilePath.toString());
                    } catch (Exception e1) {
                        e1.printStackTrace();
                        StoredObjects.LogMethod("", "Exception:--" + e1);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    StoredObjects.LogMethod("", "Exception:--" + e);
                }
            } else if (resultCode == RESULT_CANCELED) {
                // user cancelled Image capture
                Toast.makeText(getActivity(),
                        "User cancelled image picking", Toast.LENGTH_SHORT)
                        .show();
            } else {
                // failed to capture image
                Toast.makeText(getActivity(),
                        "Sorry! Failed to pick the image", Toast.LENGTH_SHORT)
                        .show();
            }

        }

        //user is returning from cropping the image
        else if (requestCode == PIC_CROP) {
            //get the returned data

            try {
                try {
                    Bitmap myBitmap = BitmapFactory.decodeFile(mCropImagedUri.getPath());
                    //ed_pro_image.setImageBitmap(myBitmap);
                    // Photo_SHowDialog(getActivity(),f_new,mCropImagedUri.getPath(),myBitmap);
                    imageupload(getActivity(),mCropImagedUri.getPath());
                } catch (Exception e) {
                    StoredObjects.LogMethod("Exception", "Exception:::" +e);
                    e.printStackTrace();
                }

                StoredObjects.LogMethod("Exception", "Exception::" + mCropImagedUri.getPath());


            } catch (Exception e1) {
                StoredObjects.LogMethod("Exception", "Exception::" +e1);
                e1.printStackTrace();
            }

        }


    }

    private Uri mCropImagedUri;
    File f_new;

    private File createNewFile(String prefix) {
        if (prefix == null || "".equalsIgnoreCase(prefix)) {
            prefix = "IMG_";
        }
        File newDirectory = new File(Environment.getExternalStorageDirectory() + "/mypics/");
        if (!newDirectory.exists()) {
            if (newDirectory.mkdir()) {
                Log.d(getActivity().getClass().getName(), newDirectory.getAbsolutePath() + " directory created");
            }
        }
        File file = new File(newDirectory, (prefix + System.currentTimeMillis() + ".jpg"));
        if (file.exists()) {
            //this wont be executed
            file.delete();
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return file;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void imageupload(final Context context, final String path){
        String fileNameSegments[] = path.split("/");
        fileName = fileNameSegments[fileNameSegments.length - 1];

        myImg = Bitmap.createBitmap(getResizedBitmap(getUnRotatedImage(path, BitmapFactory.decodeFile(path)), 300));
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        myImg.compress(Bitmap.CompressFormat.JPEG, 50, stream);
        bitmapToUriConverter(myImg);
        prf_prfle_img.setImageBitmap(myImg);

    }


    private Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public static Bitmap getUnRotatedImage(String imagePath, Bitmap rotatedBitmap) {
        int rotate = 0;
        try
        {
            File imageFile = new File(imagePath);
            ExifInterface exif = new ExifInterface(imageFile.getAbsolutePath());
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation)
            {
                case ExifInterface.ORIENTATION_ROTATE_270:
                    rotate = 270;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    rotate = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_90:
                    rotate = 90;
                    break;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }

        Matrix matrix = new Matrix();
        matrix.postRotate(rotate);
        return Bitmap.createBitmap(rotatedBitmap, 0, 0, rotatedBitmap.getWidth(), rotatedBitmap.getHeight(), matrix,
                true);
    }

    @SuppressLint("CheckResult")
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void bitmapToUriConverter(Bitmap mBitmap) {
        Uri uri = null;
        try {
            final BitmapFactory.Options options = new BitmapFactory.Options();

            File file = new File(getActivity().getFilesDir(), "DeliveryImages"
                    + new Random().nextInt() + ".png");

            FileOutputStream out;
            int currentAPIVersion = Build.VERSION.SDK_INT;
            if (currentAPIVersion > Build.VERSION_CODES.M) {
                out = getActivity().openFileOutput(file.getName(),
                        Context.MODE_PRIVATE);
            }else{
                out = getActivity().openFileOutput(file.getName(),
                        Context.MODE_WORLD_READABLE);
            }

            mBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();

            //get absolute path
/*
            new Compressor(getActivity())
                    .compressToFileAsFlowable(file)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<File>() {
                        @Override
                        public void accept(File file) {
                            compressedImage = file;
                            setCompressedImage();
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) {
                            throwable.printStackTrace();
                            showError(throwable.getMessage());
                        }
                    });
*/


        } catch (Exception e) {
            Log.e("Your Error Message", e.getMessage());
        }
    }

    private void setCompressedImage() {
        Log.i("Compressor", "Compressed image save in " + compressedImage.getAbsolutePath());
        String realPath = compressedImage.getAbsolutePath();
        if (InterNetChecker.isNetworkAvailable(getActivity())) {
          //  new ImageUploadingTask().execute(realPath);
        }else{
            Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.checkinternet), Toast.LENGTH_SHORT).show();
        }
    }

    public void showError(String errorMessage) {
        Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_SHORT).show();
    }

    public String getPath(Uri uri, Activity activity) {
        Cursor cursor = null;
        try {
            String[] projection = {MediaStore.MediaColumns.DATA};
            cursor = activity.getContentResolver().query(uri, projection, null, null, null);
            if (cursor.moveToFirst()) {
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
                return cursor.getString(column_index);
            }
        } catch (Exception e) {
        } finally {
            cursor.close();
        }
        return "";
    }

    /**
     * Crop the image
     *
     * @return returns <tt>true</tt> if crop supports by the device,otherwise false
     */

    private void captureImage() {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File file = CameraUtils.getOutputMediaFile(CameraUtils.MEDIA_TYPE_IMAGE);
        if (file != null) {
            imageStoragePath = file.getAbsolutePath();
        }

        Uri fileUri = CameraUtils.getOutputMediaFileUri(getActivity(), file);

        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);

        // start the image capture Intent
        startActivityForResult(intent, CAMERA_CAPTURE_IMAGE_REQUEST_CODE);

    }

/*
    private void requestCameraPermission(final int type) {
        Dexter.withActivity(getActivity())
                .withPermissions(Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {

                            if (type == CameraUtils.MEDIA_TYPE_IMAGE) {
                                // capture picture
                                captureImage();
                            }

                        } else if (report.isAnyPermissionPermanentlyDenied()) {
                            showPermissionsAlert();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();
    }
*/

/*
    private void requestStoragePermission(final int type) {
        Dexter.withActivity(getActivity())
                .withPermissions(Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {

                            if (type == CameraUtils.MEDIA_TYPE_IMAGE) {
                                // capture picture
                                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                startActivityForResult(intent, 2);
                            }

                        } else if (report.isAnyPermissionPermanentlyDenied()) {
                            showPermissionsAlert();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();
    }
*/

    /**
     * Alert dialog to navigate to app settings
     * to enable necessary permissions
     */

/*
    private void showPermissionsAlert() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(getActivity());

        builder.setTitle("Permissions required!")
                .setMessage("Camera needs few permissions to work properly. Grant them in settings.")
                .setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        CameraUtils.openSettings(getActivity());
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).show();
    }
*//*

    public class ImageUploadingTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(getActivity());
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                strResult = HttpPostClass.uploadFile(params[0],StoredUrls.Uploadimage_url);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {
                JSONObject jsonObject =  new JSONObject(result);
                String status = jsonObject.getString("status");
                if(status.equalsIgnoreCase("200")){
                    StoredObjects.LogMethod("response","response::"+result);
                    filename = jsonObject.getString("file_name");

                }else{
                    //after fail
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error,getActivity());
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }*/


      /*public class GetProfileTask extends AsyncTask<String, String, String> {
        String strResult = "";
        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(getActivity());
        }
        @Override
        protected String doInBackground(String... params) {
            try {

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token",params[0]));
                nameValuePairs.add(new BasicNameValuePair("type",params[1]));
                nameValuePairs.add(new BasicNameValuePair("user_id",params[2]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl,nameValuePairs);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject =  new JSONObject(result);
                String status = jsonObject.getString("status");
                if(status.equalsIgnoreCase("200")){
                    String results = jsonObject.getString("results");
                    JSONObject jsonObject1 =  new JSONObject(results);
                    String profile = jsonObject1.getString("profile");
                     getprofilelist = JsonParsing.GetJsonData(profile);
                     AssignData(getprofilelist);
                }
                else{
                    String error= jsonObject.getString("error");
                    StoredObjects.ToastMethod(error,getActivity());
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }*/

    /*public class EditPrfileTask extends AsyncTask<String, String, String> {
        String strResult = "";
        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(getActivity());
        }
        @Override
        protected String doInBackground(String... params) {

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                //Api.php?token=Mikel&type=edit_profile&address_line=123&city=dhaka&gender=male&phonenumber=123123&pic=11.png&user_id=1

                nameValuePairs.add(new BasicNameValuePair("token",params[0]));
                nameValuePairs.add(new BasicNameValuePair("type",params[1]));
                nameValuePairs.add(new BasicNameValuePair("address_line",params[2]));
                nameValuePairs.add(new BasicNameValuePair("city",params[3]));
                nameValuePairs.add(new BasicNameValuePair("gender",params[4]));
                nameValuePairs.add(new BasicNameValuePair("phonenumber",params[5]));
                if(params[7].equalsIgnoreCase("no_image")){

                }else{
                    nameValuePairs.add(new BasicNameValuePair("pic",params[6]));
                }
                nameValuePairs.add(new BasicNameValuePair("user_id",params[8]));
                nameValuePairs.add(new BasicNameValuePair("user_id",params[8]));
                nameValuePairs.add(new BasicNameValuePair("name",params[9]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl,nameValuePairs);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject =  new JSONObject(result);
                String status = jsonObject.getString("status");
                if(status.equalsIgnoreCase("200")){
                    StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.profiledetailsupdated),getActivity());

                    if (InterNetChecker.isNetworkAvailable(getActivity())) {
                        new GetProfileTask().execute(StoredObjects.token,StoredUrls.getprofile,StoredObjects.UserId);
                    }else{
                        StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet),getActivity());
                    }

                }else{
                    String error= jsonObject.getString("error");
                    StoredObjects.ToastMethod(error,getActivity());
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }*/

   /* private void AssignData(ArrayList<HashMap<String, String>> getprofilelist) {

        String email = getprofilelist.get(0).get("username");
        String subscribe = getprofilelist.get(0).get("subscribed");
        String idno = getprofilelist.get(0).get("idno");
        String userid = getprofilelist.get(0).get("user_id");
        String name = getprofilelist.get(0).get("name");
        String adresline = getprofilelist.get(0).get("address_line");
        String city = getprofilelist.get(0).get("city");
        String gender = getprofilelist.get(0).get("gender");
        //StoredObjects.name = getprofilelist.get(0).get("name");
       // StoredObjects.mobilenum = getprofilelist.get(0).get("username");
        String phoneno = getprofilelist.get(0).get("username");
        String alterphneno = getprofilelist.get(0).get("alternate_phone");
        String idproof = getprofilelist.get(0).get("id_proff");
        String adresprof = getprofilelist.get(0).get("address_proff");
        String bikergstn = getprofilelist.get(0).get("bike_registration_num");
        String drbnglicnce = getprofilelist.get(0).get("driving_licence");
        String createdate = getprofilelist.get(0).get("created_on");
        String stausbit = getprofilelist.get(0).get("status_bit");

        prf_name_edtx.setText(name);
        prf_gendr_edtx.setText(gender);
        //prf_age_edtx.setText(name);
        prf_email_edtx.setText(email);
        prf_city_edtx.setText(city);
        prf_phone_edtx.setText(phoneno);
        prf_adres_edtx.setText( adresline );

        Glide.with(getActivity())
                .load(Uri.parse(StoredUrls.Displayimage_url+ getprofilelist.get(0).get("pic"))) // add your image url
                .centerCrop() // scale to fill the ImageView and crop any extra
                .fitCenter() // scale to fit entire image within ImageView
                .placeholder(R.drawable.imagenotfound)
                .into(prf_prfle_img);
    }*/

    public void fragmentcalling(Fragment fragment){
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }
}
